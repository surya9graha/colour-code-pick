// Tab Switching logic
const tabs = document.querySelectorAll('.tab-btn');
const panes = document.querySelectorAll('.tab-pane');

tabs.forEach(tab => {
    tab.addEventListener('click', () => {
        tabs.forEach(t => t.classList.remove('active'));
        panes.forEach(p => p.classList.remove('active'));
        
        tab.classList.add('active');
        document.getElementById(tab.dataset.tab).classList.add('active');
    });
});

// Utilities
function randomHex() {
    return '#' + Math.floor(Math.random() * 16777215).toString(16).padStart(6, '0');
}

function hexToRgb(hex) {
    let r = 0, g = 0, b = 0;
    if (hex.length === 4) {
        r = parseInt(hex[1] + hex[1], 16);
        g = parseInt(hex[2] + hex[2], 16);
        b = parseInt(hex[3] + hex[3], 16);
    } else if (hex.length === 7) {
        r = parseInt(hex.substring(1, 3), 16);
        g = parseInt(hex.substring(3, 5), 16);
        b = parseInt(hex.substring(5, 7), 16);
    }
    return `rgb(${r}, ${g}, ${b})`;
}

// Copy to Clipboard
function copyText(elementId, textDirect = null) {
    const text = textDirect || document.getElementById(elementId).innerText;
    navigator.clipboard.writeText(text).then(() => {
        showToast();
    });
}

function copyDirect(text) {
    navigator.clipboard.writeText(text).then(() => {
        showToast();
    });
}

function showToast() {
    const toast = document.getElementById('toast');
    toast.classList.add('show');
    setTimeout(() => {
        toast.classList.remove('show');
    }, 2000);
}

// --- Solid Color Logic ---
const solidDisplay = document.getElementById('solidDisplay');
const hexValue = document.getElementById('hexValue');
const rgbValue = document.getElementById('rgbValue');
const nativePicker = document.getElementById('nativeColorPicker');

function updateSolidColor(hex) {
    solidDisplay.style.backgroundColor = hex;
    hexValue.innerText = hex.toUpperCase();
    rgbValue.innerText = hexToRgb(hex);
    nativePicker.value = hex;
}

function generateSolid() {
    updateSolidColor(randomHex());
}

nativePicker.addEventListener('input', (e) => {
    updateSolidColor(e.target.value);
});

// --- Gradient Logic ---
const gradientDisplay = document.getElementById('gradientDisplay');
const gradientCss = document.getElementById('gradientCss');

function generateGradient(type = 'linear') {
    const color1 = randomHex();
    const color2 = randomHex();
    
    let css = '';
    if (type === 'linear') {
        const angle = Math.floor(Math.random() * 360);
        css = `linear-gradient(${angle}deg, ${color1}, ${color2})`;
    } else {
        css = `radial-gradient(circle, ${color1}, ${color2})`;
    }
    
    gradientDisplay.style.background = css;
    gradientCss.innerText = css;
}

// --- Palette Logic ---
const paletteDisplay = document.getElementById('paletteDisplay');

function renderPalette(container, colors) {
    container.innerHTML = '';
    colors.forEach(color => {
        const hex = color.toUpperCase();
        const div = document.createElement('div');
        div.className = 'palette-color';
        div.style.backgroundColor = hex;
        div.onclick = () => copyDirect(hex);
        div.title = "Click to copy";
        
        const span = document.createElement('span');
        span.className = 'palette-hex';
        span.innerText = hex;
        
        div.appendChild(span);
        container.appendChild(div);
    });
}

function generatePalette() {
    const colors = Array.from({length: 5}, () => randomHex());
    renderPalette(paletteDisplay, colors);
}

// --- API Palette Logic ---
const apiDisplay = document.getElementById('apiDisplay');
const apiBtn = document.getElementById('apiBtn');

async function generateApiPalette() {
    apiBtn.innerText = 'Fetching...';
    apiBtn.disabled = true;
    
    try {
        const baseColor = randomHex().substring(1); // remove #
        const response = await fetch(`https://www.thecolorapi.com/scheme?hex=${baseColor}&mode=analogic&count=5`);
        const data = await response.json();
        
        const colors = data.colors.map(c => c.hex.value);
        renderPalette(apiDisplay, colors);
    } catch (error) {
        console.error('Error fetching from API', error);
        alert('Failed to fetch from API. Showing random palette instead.');
        const colors = Array.from({length: 5}, () => randomHex());
        renderPalette(apiDisplay, colors);
    } finally {
        apiBtn.innerText = 'Fetch from API';
        apiBtn.disabled = false;
    }
}

// Initialize everything on load
generateSolid();
generateGradient('linear');
generatePalette();
generateApiPalette();
